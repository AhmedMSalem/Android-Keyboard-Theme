/** Automatically generated file. DO NOT MODIFY */
package gt.keybord.elephant;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}