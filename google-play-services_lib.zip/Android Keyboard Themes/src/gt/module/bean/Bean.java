package gt.module.bean;

import android.R.string;
import android.graphics.drawable.Drawable;

public class Bean {
	
		public Drawable background;
	    public Drawable keyBackground;
	    public string keyTextColor;
	    
	    public void release() {

	    }
	    
}
